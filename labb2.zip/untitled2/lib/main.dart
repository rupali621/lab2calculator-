import 'package:flutter/material.dart';

void main() => runApp(CalculatorApp());

class CalculatorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Simple Calculator',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: CalculatorHomePage(),
    );
  }
}

class CalculatorHomePage extends StatefulWidget {
  @override
  _CalculatorHomePageState createState() => _CalculatorHomePageState();
}

class _CalculatorHomePageState extends State<CalculatorHomePage> {
  String _expression = '';
  String _result = '0';

  void _onButtonClick(String char) {
    setState(() {
      switch (char) {
        case 'C':
          _clear();
          break;
        case 'CE':
          _clearEntry();
          break;
        case '=':
          _calculateResult();
          break;
        default:
          _appendCharacter(char);
      }
    });
  }

  bool _isOperator(String char) {
    return char == '+' || char == '-' || char == '*' || char == '/';
  }

  void _appendCharacter(String char) {
    if (_expression.length < 8 || _isOperator(char)) {
      _expression += char;
      _result = _expression;
    }
  }

  void _clear() {
    _expression = '';
    _result = '0';
  }

  void _clearEntry() {
    if (_expression.isNotEmpty) {
      _expression = _expression.substring(0, _expression.length - 1);
      _result = _expression.isNotEmpty ? _expression : '0';
    }
  }

  void _calculateResult() {
    try {
      _result = _evaluateExpression(_expression);
      _expression = _result;
    } catch (e) {
      _result = 'ERROR';
    }
  }

  String _evaluateExpression(String expression) {
    try {
      final sanitizedExpression = expression.replaceAll('×', '*').replaceAll('÷', '/');
      final result = double.parse(sanitizedExpression);
      return result.toStringAsFixed(8);
    } catch (e) {
      throw Exception('Invalid expression');
    }
  }

  Widget _buildButton(String label, {Color? color, Color? textColor}) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(4.0), // Add padding for spacing
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: color ?? Colors.grey[850], // Darker background color for realism
            foregroundColor: textColor ?? Colors.white, // White text color
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8), // Slightly rounded corners
            ),
            minimumSize: Size(double.infinity, 80), // Increase button height
          ),
          onPressed: () => _onButtonClick(label),
          child: Text(
            label,
            style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold), // Slightly smaller text size
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Calculator'),
      ),
      body: Column(
        children: <Widget>[
          Container(
            alignment: Alignment.centerRight,
            padding: EdgeInsets.all(20.0),
            child: Text(
              _result,
              style: TextStyle(fontSize: 48, fontWeight: FontWeight.bold),
            ),
          ),
          Divider(thickness: 1.0),
          Expanded(
            child: Column(
              children: <Widget>[
                Row(
                  children: <Widget>[
                    _buildButton('CE', color: Colors.red),
                    _buildButton('C', color: Colors.red),
                    _buildButton('÷', color: Colors.orange),
                    _buildButton('×', color: Colors.orange),
                  ],
                ),
                Row(
                  children: <Widget>[
                    _buildButton('7'),
                    _buildButton('8'),
                    _buildButton('9'),
                    _buildButton('-', color: Colors.orange),
                  ],
                ),
                Row(
                  children: <Widget>[
                    _buildButton('4'),
                    _buildButton('5'),
                    _buildButton('6'),
                    _buildButton('+', color: Colors.orange),
                  ],
                ),
                Row(
                  children: <Widget>[
                    _buildButton('1'),
                    _buildButton('2'),
                    _buildButton('3'),
                    _buildButton('=', color: Colors.orange),
                  ],
                ),
                Row(
                  children: <Widget>[
                    _buildButton('0', color: Colors.grey[700]),
                    _buildButton('.'),
                    _buildButton(''),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
